# 云上小屋 Cloud Cabin 1.5.8 测试版

云上小屋是 Nomad Drive 的单机模组。按 **B** 打开手账，生成装饰和家具，或前往悬空岛「小家」。需要 **BepInEx 5 x64 / Mono**，适用于 Unity **6000.0.73f1** 的游戏版本。

## 安装与升级

1. 退出游戏，备份游戏存档、`BepInEx/config` 及旧版云上小屋插件目录，包括之前的 1.5.8 测试版。旧插件已在 `BepInEx/plugins/CloudCabin/` 时，将整个旧目录移出 `plugins`，并把自定义预设的子文件夹完整复制到 `BepInEx/config/CloudCabin/presets/`，保留 `preset.json` 和 `paint/`。旧插件若使用更早的目录名，也可只移出旧 DLL，保留其余数据供新版读取。
2. 将 `CloudCabin-1.5.8.zip` 解压到游戏根目录。确认只有新版 `BepInEx/plugins/CloudCabin/CloudCabin.dll` 会被加载。
3. 启动游戏。首次启动且新配置文件尚未创建时，插件会自动导入旧设置到 `BepInEx/config/com.momo_zf.cloudcabin.cfg`，并从旧配置目录恢复小家快照及备份。新版自动识别旧存档和预设里的杯子，在手账中显示为「云上小屋杯」。用户预设目录中的同名预设优先生效。进入单机存档后按 **B**，确认手账右上角显示「1.5.8 测试版」。

## 1.5.8 物品携带与地图往返

当前目录的 24 件物品都使用原版 Mug 的 **0.5 kg** 质量，沿用原版即时拾取、冲刺和 Q 投掷规则。下文各历史版本记录中的质量为当时的设定。

**B 手账**依次显示「全部、家具、厨房、装饰、户外、原版物品、地图」。全部页收录四个分类的 24 件目录物品。地图页显示小家和已安装的扩展地图。小家六扇窗和正门均可从室内外按原版主交互键开合，打开后也可瞄准洞口关上。

**单机删除**时，瞄准可删除物品后按 **K**。没有可删除的瞄准目标时，手持物品可用同一按键删除，提示会写明删除手持物品。适用对象为已放入世界的 云上小屋目录物品，以及本版更新后从手账生成、存档中带来源标记的原版物品。原版旧存档中缺少来源标记的实例受保护。删除储物柜时，抽屉和柜内搁板上的物品会解除储物关系并落到下方地面，继续按普通物品保存。原世界在下一次游戏存档时记录删除，小家会立即保存地图物品和备份。导演模式内 K 由原版镜头关键帧操作使用。Rewired 键位中存在 K 时，删除与提示也会暂停。

# 1.5.7-preview 地图列表与小家保存

本次新增四件普通可生成、拾取、移动及摆放的庭院道具：**门廊椅、野餐桌（连体长凳）、篝火石圈（静态装饰）、庭院串灯（静态装饰）**。在 **B → 装饰 / 全部** 选择对应中文卡片与设计图标生成；小家首次访问每存档生成两把门廊椅、野餐桌、篝火石圈和串灯，都是可移动并保存的普通物品；室内继续空置。其他地图不自动生成这批道具。

| 永久 id | 宽 X × 深 Z × 高 Y（米） | 碰撞与承托 |
|---|---|---|
| `porch_chair` | 0.750 × 0.8966 × 0.950 | 设计师整体凸盒；不提供座椅交互或物品承托 |
| `picnic_table` | 1.800 × 1.490 × 0.760 | 13个根部凸碰撞体；桌面高0.76米、凳面高0.45米；接入现有 ItemSurface |
| `campfire_ring` | 可见1.3162 × 1.3095 × 0.620；凸壳约1.3841 × 1.3841 × 0.620 | 保留包围石圈与火焰高度的设计师凸壳；无承托标记 |
| `string_lights` | 5.400 × 0.400 × 2.620 | 18个立柱/底脚/支撑凸碰撞体；灯下通道留空，线缆与灯泡仅显示 |

四件均使用现有 plain donor 与原生摆放保存组件；质量8/35/25/12 kg为预览用估值。永久 GUID/Address/asset ID 沿用已有按 id 派生算法；同类多个实例由原生 PersistentObject 分配不同实例身份。小家内放下的物品沿用按存档槽、地图隔离的保存。`Loot.RandomSpawn=false` 继续默认关闭，显式开启后四件也会参与现有随机目录。

导出 GLB 的 `COLOR_0 × baseColorFactor` 使用地图同一套 PCA 调色板烘焙算法，生成 sRGB RGBA32 纹理与 UV0供HDRP/Lit读取。篝火与灯泡保留设计师静态发光材质；没有火焰动画、实时光源、开关、取暖/烹饪或伤害机制。尚未进游戏验收；拾取手势、大尺寸摆放、复合碰撞体创建、桌凳承托、存档重进与实际HDRP显示按 `TESTING_map_zh.md` 检查。

本轮另加四件普通摆件：**腌橄榄罐、收拢雨伞、足球、紫花盆栽**；四件也在 **B → 装饰 / 全部** 使用设计师图标生成，不进入任何地图默认列表。目录共21件，小屋仍为空。没有饮用/开伞/踢球/种植机制。

| 永久 id | 可见宽 X × 深 Z × 高 Y（米，约） | 质量 / 设计师凸碰撞 |
|---|---|---|
| `olive_jar` | 0.100 × 0.100 × 0.142 | 0.75 kg / 44三角面凸壳 |
| `umbrella` | 0.1048 × 0.0512 × 0.8801 | 0.6 kg / 96面凸壳，底端加宽，柄钩空隙包在凸壳内 |
| `soccer_ball` | 0.2191 × 0.2183 × 0.220 | 0.43 kg（估值）/ 80面凸壳，局部约4毫米偏差 |
| `flower_pot` | 0.2044 × 0.2030 × 0.2317 | 1.6 kg / 88面凸壳，包含花叶空隙 |

四个GLB均无 `COLOR_0`，所以不需要调色板烘焙，沿用独立材质的线性 `baseColorFactor` 与原有UV。材质克隆清除继承的底色贴图，使用导出粗糙度/金属度与双面标记；花叶双面薄片关闭剔除。玻璃罐与卤水使用现有原版透明材质克隆，保留0.22/0.18透明度；不实现glTF transmission、IOR、体积吸收或clearcoat扩展，实际玻璃排序/内部橄榄可见度需实机检查。既有四件庭院道具继续走HDRP调色板路径。八件均沿用原生拾取/摆放与地图独立保存；不是自动布景。

B 手账「地图」按顺序列出小家与已安装的扩展地图。每张卡片可步行或带停稳原车进入。小家使用 maps/home/map.json 与批准的木屋庭院GLB：40米外圈、25米院子、8.5×6.5米木屋，前门、两扇院门和六扇窗可开合并保存。室内仅建筑框架与固定灯具，无家具。庭院默认五件仅在 defaultsSpawned=false 时生成，移走后不补生。步行 (-4.4,0,-2.6) 面向门22.8°；车辆 (4.95,0.02,4.8) 朝南180°，玩家在驾驶员左侧 (6.75,0.02,4.8) 看向车。

小家物品及门窗状态按游戏存档分开保留：`BepInEx/config/CloudCabin/mapsaves/<slot>/<mapId>.json`，包含 `.bak` 原子备份。进入前仍保存原世界检查点；地图内锁世界存档，物品文件在进入恢复后、变化时每20秒、尝试保存、返回前及有效退出时保存。返回后在地图内的物品（包括外面带进来再放下的物品）存入文件并清除现场；背包/手持/车上物品随游戏走。外世界成功保存后清掉已带走记录。直接在小家退出，再读档时人在出发点，从B菜单重进恢复；已有同GUID物品不会重复生成。强退最多回到最近成功地图快照；退出已开始拆场景时保留上次文件，不用半销毁场景覆盖。

若上次直接在地图内退出，尚未在当前世界出现的 carried 记录保留到再次进入，避免原世界自动存档抹掉检查点回滚的恢复机会。两份文件都坏时隔离 `.corrupt-<UTC时间>` 并恢复为空地图（小家无默认物品）。请保持空手往返；返回前等抛出的物品落稳。车辆不写入地图文件，只支持原车往返；不要用控制台在小家生成其他车辆。

看门窗后按游戏原生主交互键（保留玩家自己的键位）显示开门/关门/开窗/关窗，无新增F键。静态支持面用Ground碰撞，可按原生R摆放；活动门窗叶片用Interactable，不承诺承载摆放物。无居中提示，地图状态在B菜单底部及日志。

地图扩展规则见 [maps/README.md](maps/README.md)。单机/房主预览，尚需实机验收；更早版本说明保留如下。

# 云上小屋 Cloud Cabin 历史版本说明

Adds a double-wall Cloud Cabin Cup, microwave, Christmas tree, laptop, small pedal trash can, desk lamp, tabletop Christmas tree, gift box, washer, upright piano, yellow paper rabbit, platypus plush and lighthouse model to Nomad Drive. Requires **BepInEx 5 x64 / Mono**, and the supplied game build using Unity **6000.0.73f1**. GUID: `com.momo_zf.cloudcabin`.

## 1.5.4：原版物品菜单与新版纸兔子

按 **B → 原版物品**：原版页与模组页共用拍立得图标网格、纸张/阴影/胶带、选中圈和动画。点击分类纸签切换，页眉搜索框支持中文/英文/prefab/地址/GUID和中文IME；滚轮按行、PgUp/PgDn及底部按钮翻页，四方向键选择，Enter/生成按钮或双击生成。搜索中B不关闭菜单，结束后点击卡片再按Enter。

1.5.4修订时的行为：生成成功/失败仅输出 `Spawn menu:` 日志，取消误用的居中8秒预设条；预设提示保持原样。220项均有GUID中文映射：205个游戏基础中文、15盘人工翻译磁带，补充车型/款式区分。随包 `vanilla_names.zh-Hans.json` 优先使用游戏运行时zh-Hans，外部表缺失/损坏时用DLL内嵌表。完整GUID/英文/中文/来源见 `names_zh.csv` 和 `RELEASE_1.5.8.md`。

打开原版物品页时才加载目录和可见卡片的图标。图标优先使用 Addressables prefab 的原生 `inventoryIcon`，缺图标的物品用网格和简单材质颜色绘制 128 px 离屏缩略图，每帧最多一张。缩略图只缓存在内存里。绘制失败时显示“图标暂不可用”并写入日志。
目录在运行时读取 Addressables 的 **Loot / GameObject**，通过 GUID 别名去重，不内置原版物品名单。按本次 catalog/实际 prefab 的离线审计，227 个候选中可生成 **220 种原版物品**：家具55、车辆零件69、杂项39、工具19、食物18、厨房8、饮品6、种子4、电子设备2。游戏本身没有归到 Container 的独立条目；不按名称猜分类。加上十七件模组物品，当前共 237 种。实际数量由游戏 catalog、加载结果与主机配置决定；日志 `Vanilla catalog` 会输出本次分类统计。

默认排除五个车架（含摩托车）、固定水泵储液器，以及依赖油泵/软管的 GasPumpNozzle。额外排除用配置 `[SpawnMenu] VanillaExclusions`，逗号/分号分隔精确 GUID、Addressables 地址或 prefab 名；默认值 `GasPumpNozzle`，重启后生效。无稳定 GUID、有效根网络身份、根 HeldItem，或有嵌套身份/sceneId/serverOnly 的资源也会拒绝。`ExcludeFromProceduralSpawn` 不用于菜单过滤，保留彩色家具、钥匙、箱子及可拾取零件。

本发布版的生成菜单与地图测试均面向单机游玩。
纸兔子改用设计已放大1.3倍的新 GLB，实测宽×深×高 **5.72×10.575×11.70厘米**，根凸碰撞体和 footprint 同尺寸、中心Y=.0585米、底部Y=0；代码无额外缩放。均匀放大不改变图标外观比例，沿用已有透明图标。永久GUID/地址/asset ID、质量保持不变。

`Loot.RandomSpawn` 默认false和全部原随机掉落补丁保持不变；菜单不进入世界生成ledger。未新增整车生成功能，整车相关代码、三份内置预设JSON与涂装文件逐字节保留1.5.3版本（其pluginVersion仍为1.5.3）。本包是 **preview / in_game_verified=false**。安装与完整中文验收见 [TESTING_zh.md](TESTING_zh.md)，交付范围和离线统计见 [final.md](RELEASE_1.5.8.md)。

以下章节保留旧版本的功能与研究记录。

## 1.5.3：三件装饰

按 **B → 装饰**（或“全部”）生成；三件均使用 plain donor，质量为预览用估值，沿用原生拾取、R 放置、Q 抛掷、存档与多人替身机制。保留 1.5.2 的十件物品、三车内置预设和全部既有功能。

| 菜单名 / 永久 id | 可见尺寸（宽 X × 长 Z × 高 Y） | 质量 | 模型 |
|---|---|---|---|
| 纸兔子 / `paper_rabbit` | 5.72 × 10.575 × 11.70 cm（1.5.4 更新） | 0.005 kg | 黄色 `paper_rabbit.glb`，不使用蓝黄版 |
| 鸭嘴兽玩偶 / `platypus_plush` | 16.51 × 29.5 × 26.05 cm（约 26.1） | 0.3 kg | `platypus_plush.glb` |
| 灯塔模型 / `lighthouse_model` | 11 × 11 × 36 cm | 0.6 kg | `lighthouse_model.glb` |

GLB 直接按米读取，不额外缩放；可见模型和根部凸碰撞体的底部均为 Y=0。鸭嘴兽素材的包络碰撞壳约 **18.03 × 31.87 × 26.44 cm**，略大于可见布偶；保留原壳，不能按壳反向缩小模型。离线 footprint 也使用实测包络及微小的非零中心偏移。

灯塔 `LanternGlow` 上的 **LampGlow / LampCore** 保持原生 HDRP 发光材质克隆，保留线性暖色与强度 **3 / 6**，清除继承的发光贴图/倍率。与台灯共用 ItemMaterials 路径，所有发光材质必须克隆可工作的 HDRP 发光变体。灯塔**常亮**，无开关、额外场景灯或状态同步；玻璃沿用素材的 OPAQUE 状态并自发光（内部 LampCore 被玻璃遮挡是素材原状）。缺少合适原生材质时会记录错误并采用现有几何回退，需检查日志，不能当成灯塔正常显示。

`Loot.RandomSpawn` 默认 **false**，统一覆盖十七件目录项及全部随机掉落补丁；仅保留 B 菜单生成/存档所需注册。若旧配置曾设为 true，测试前改回 false。目录协议升为 **10503**，旧十件 GUID/地址/asset ID 不变，旧版本玩家继续使用原生替身。

1.5.3 历史离线结果：Release **0 警告 / 0 错误**；C# **922,478** 项检查通过，Python 预设 **107** 项、涂鸦 **21** 项通过，三份内置预设及全部涂装 PNG 通过生产解析器校验。

本版实机重点：对照上表确认大小/图标/中文名，三件在地面与桌面反复拾取、R 预览/取消/放下、Q 轻抛/蓄力抛掷；放下后不悬空、不陷入。夜间检查灯塔玻璃持续暖色发光且框架不发光，保存重载后仍正确；回测原台灯开关、门/琴盖开合、预设和旧存档，并验证默认无随机掉落。离线回归不能替代 Unity HDRP、物理或 Mirror 实机验证。

## 1.5.2：三车内置预设与涂装

合并离线预设生成、涂鸦 UV 烘焙和轴向核对工具。三车按 **+Z 车头、+X 入口侧，不镜像** 生成；保留 1.5.1 的十件物品、洗衣机/琴盖开合及质量设置。`Loot.RandomSpawn` 仍默认 **false**，B 菜单和旧存档物品正常注册。

| 预设文件夹 | 车型 / 主题 | 清单物品 / 喷漆 PNG | 测试状态 |
|---|---|---|---|
| `school_bus` | RV-SchoolBus / 音乐客厅＋洗衣角 | 33 / 4（4 张设计贴花） | 车型与引擎盖身份已绑定，可试用 |
| `retro_rv` | RV-1986 / 复古创作者书房 | 32 / 6（5 张设计贴花） | 身份已绑定；已重烘尾灯之间的后条纹及避开门洞的右条纹 |
| `c_class_rv` | Rv-C / 圣诞小木屋 | 23 / 26（6 张设计贴花） | **UNBOUND：真实车型 GUID 未知，暂不能应用** |

校车车型 GUID 为 `df321578632574b4a9d3394dbb489933`，复古 RV 为 `d699ecbfb8a228245ab2a9867bc962e5`。
C 型车保留全零车型/部分零件占位；自动选择会排除它，显式选择也会在修改车辆前显示“尚未绑定真实车型 GUID”。
以后捕获真实车型和各喷漆零件 GUID 后才能重新生成并启用。

“预设已导出”“预设完成”和错误提示均改为**屏幕中央、1080p 下 32 号加粗字、8 秒**，使用手账菜单相同的奶油纸底、深色字、铁锈红边框与中文字体回退。提示自动换行，按实时时间计时，不受游戏时间缩放影响。

安装与测试：

1. 关闭游戏并备份存档/旧插件，解压 `CloudCabin-1.5.8.zip` 到游戏根目录，保持 `BepInEx/plugins/CloudCabin/` 层级。
2. 开单人本地主机，停车，准备**没有已放置物品**的校车或复古 RV，站在车内/车上；关闭菜单和导演模式，按 **Ctrl+Shift+P**。
3. `Preset.ActivePreset` 默认为空，按车型名＋真实 GUID 选择最新匹配预设。如有自己的更新导出，可填写 `school_bus` / `retro_rv` 指定测试内置版本；错误车型会拒绝，非空车辆也会拒绝。
4. 查看居中提示的成功/跳过数及 `BepInEx/LogOutput.log`；核对内饰朝向、门侧、校车音符/琴键与 RV 门洞/尾灯附近涂装。正常保存、退出并重载，检查已成功应用的摆件与涂装。
5. 设 `Preset.DevExport=true` 后按 **Ctrl+Shift+E** 验证“预设已导出”；在非空车上再次应用验证错误提示。1080p / 1440p / 窄屏都要确认中文清晰、长路径换行、显示约 8 秒。

**本版仍是离线验证的测试包。** 三车生成检查均为 0 errors，NEW_ITEM 不导出；校车有 **16** 个、复古 RV 有 **17** 个、C 型车有 **9** 个叠放条目仍用 `planeId=0` 和假设的父物品顶面帧。实际没有对应原生平面时会跳过该条目及其子链，当前不能保证整套家具/小摆件全部恢复。需在游戏捕获真实物品平面/姿态后替换；ItemSurface 不能代替 SnappingPlane。
复古 RV 的实机夜柜与安装门侧证据冲突仍保留警告；校车防撞条等不可喷区域会裁掉部分贴花像素（侧面约 90%、尾部约 85% 落点），复古 RV 门贴花约 84%。UV 重叠、Unity 的颜色/遮罩上传、原生存档和中文字体仍需实机确认。应用可部分成功，重试前请清空车内已放置物品；多人模式会拒绝。

发行目录为 `dist/BepInEx/plugins/CloudCabin/`，ZIP 仍沿用 1.5.1 层级。内置预设目录只含我们生成的 `preset.json` 和 `paint/*.png`；网格、原生材质、安装捕获和 Blender 工程均不随包发布。


## 1.5.1 preview：洗衣机与钢琴

按 **B**，在厨房分类选择“洗衣机”，在装饰分类选择“钢琴”。两件都用 plain donor，原生拾取/R 放置与存档保持现有机制。模型闭合尺寸（宽×高×深）为洗衣机 **0.60×0.85×0.55 m**，钢琴 **1.42×1.08×0.56 m**，底部中心原点，不缩放。

| id | GUID | Mirror asset ID | 游戏质量 | surface |
|---|---|---|---|---|
| washer | `0cd4ee79749228823518aabb87e7517b` | `0CD4EE79` | 65 kg | true |
| piano | `49accce0c91a6836f6d94e9ffa7a2e2e` | `49ACCCE0` | 50 kg（设计 200 kg） | true |

洗衣机门使用反射后节点帧铰链 `(0.225, 0.400, 0.275)`，本地 **Y 0→+120°** 朝柜外开；次要提示“开门 / 关门”。钢琴琴盖铰链 `(0, 0.753, 0.100)`，本地 **X 0→−100°**，前缘上抬并向后；次要提示“打开琴盖 / 合上琴盖”。均为 0.35 秒平滑开合，只限单人本地主持，拾取/R/重载关闭，加入玩家时关闭，不存档或同步开合。碰撞体固定为关闭外形，门/琴盖只有视觉动画。

几何测试用实际 GLB 三角形检查完整角度范围，以每 0.1° 区间的最大旋转位移扩张包络，覆盖采样间隙。洗衣机门在柜前板 Z=.235 后方的部分始终位于真实鼓筒开孔内（玻璃关闭时本来伸入鼓筒）；−30° 反例穿入前板。琴盖负 X 扫掠清避最高琴键 .731 m，+30° 反例向琴键下沉。玻璃 Alpha=.35 / BLEND，沿用克隆原生 HDRP 透明材质、仅改颜色的路径。

两个凸碰撞体均有水平实体顶面：洗衣机 Y=.85，面积 .3300 m²；钢琴 Y=1.08，面积 .5041 m²（顶面深约 .355 m，小于整体深 .56 m）。启用 ItemSurface，洗衣机上可放礼物盒；移动支撑后沿用原生 detach flight。钢琴顶面叠放应限于实际平顶范围，离线整体 bbox 不能代表其斜面。

钢琴设计质量为 **200 kg**，本预览使用 **50 kg 上限**：插件在复制 Mug 刚体后直接赋 mass，原生没有通用刚体质量钳制。放好是 kinematic/rest，cargo contact filter 屏蔽车体接触，不通过此物品接入 MassAffector；原生车辆配件的质量增量是另一条路径。携带减速曲线默认 5→50 kg、最多减速 50%，10 kg 起禁冲刺；默认抛掷上限 15 kg 是“禁止抛掷”门槛，并不降低刚体质量。200 kg 在脱离支撑/坠落时仍参与动态冲量和碰撞质量分配，因此采用 50 kg 保留重家具手感并降低冲击风险。这是预览取值，不能代替实机验证；洗衣机按交付使用 65 kg，两件的 Q 抛掷可能被原生重物规则拒绝。

两件 lootWeight=.1，与大圣诞树一致；仅在显式开启 Loot.RandomSpawn 时参与程序战利品。GLB 尺寸使其成为 Large，沿用 IndoorFloor / OutdoorGround、Occasional、每 POI 最多一件及 6–12 POI 间隔策略；厨房/家具类别沿用微波炉/树的筛选，不保证每次出现。旧八件的身份不变，目录协议升为 **10501**，不兼容旧目录的玩家沿用原生替身。

`preset_gen` 识别 `MOD:washer` / `MOD:piano`，目录 footprint 优先于过期外部 bounds；即使缺少外部模型行也能解析。洗衣机叠放验证使用 .85 m 顶高和 surface=true；当前生成器仍输出需游戏捕获的 planeId=0 叠放预览，ItemSurface 不等于 SnappingPlane。正式应用前需捕获实际 rest/plane 数据。

实机待验：中文图标/菜单与原生次要键提示、门/琴盖外观及玻璃排序；两件各 20 次拾取/R/取消/释放与原生重物 Q 行为；洗衣机上礼物盒及原生 Mug 的 R/Q、移走支撑、边缘、存档重载；钢琴实际平顶；三车型上行驶/刹车/碰撞/货物脱离；旧存档、远端加入和退出世界。离线测试不证明 Unity/HDRP/物理/网络运行效果。

## 玩家说明：圣诞小树与礼物盒（同为 1.4.1）

按 **B** 打开手账，在装饰或节日分类生成“圣诞小树”或“礼物盒”。圣诞小树是新的 **60 cm** 小树（3 kg，`tabletree`），不替换原来的约 91 cm 圣诞树（`xmastree`），两者独立保留。可照常拾取和 R 放置；星星和 21 个灯泡的暖琥珀色 `Glow` 保持模型原样，本版没有灯光开关，也不新增照明灯。

礼物盒（1 kg，`giftbox`）关闭时宽 30 × 深 30 × 高 25 cm。像笔记本一样，放好后对准它，按原生次要交互“打开 / 关闭”提示的键开合，主要交互仍为拾取。盖子绕本地 X 从 0° 转到 −110°，耗时 0.35 秒，铰链为 `(0, 0.165, -0.1485)`；碰撞体始终保持关闭形状。沿用现有单人本地主持限制，开合不存档、不同步，每次启动或重新启用从关闭开始，拾取及 R 放置立即关闭。

Permanent identities: `tabletree` GUID `34be5c3854d5a1d6a37e797b0f4dc5cf`, asset ID `34BE5C38`; `giftbox` GUID `e4f88dd62749628ea2ebe237eeff28a4`, asset ID `E4F88DD6`. The original `xmastree` row and identities are unchanged.

## 玩家说明：台灯

按 **B** 打开手账，在装饰分类生成“台灯”。放好后用准星对准它，按原生次要交互提示“开灯 / 关灯”显示的键切换灯光；主要交互仍然拾取，没有新增快捷键。台灯重 **1.2 kg**，拾取及 R 放置不会关灯。灯光状态仅在本地生效，不存档、不同步，每次启动、加载、生成或重新启用都从关闭开始。

模型使用 `lamp.glb`，目录查找为 `<model-root>/lamp/lamp.glb`；`items.json` 的 `glb` 与 `lamp.bulb`（`Bulb`）是命名配置，对应 `LampSettings.GlbFile` / `BulbName` 常量。更换模型或灯泡节点名时一并更新这些值并重建；灯泡材质名为 `LampSettings.BulbMaterial`（`BulbGlow`）。真实模型缺失或不符合要求时不生成占位台灯。

The local HDRP spot uses 450 lm, 3 m range, an 80° cone with 50% inner cone, medium-resolution soft shadows and a world-down direction tilted 10° toward the front. RGB (1, .85, .65) approximates 3000 K; temperature metadata is 3000 K with additional temperature multiplication disabled. The bulb clones a working native HDRP emissive material per instance; emission is EV100 9 (64 cd/m² before the warm tint) when on, zero when off. Parameters live in `LampSettings`. The optional point fill is omitted to limit runtime HDRP setup pending a live-game check. Arms and shade remain static.

Local native API inspection confirms the secondary BasicInteraction callback executes through the local input dispatcher, without a host-only lamp condition. Check prompt/binding rendering, light appearance/shadows, pickup/R while lit, save/reload starting off, and repeat the toggle checks in single-player.

## Microwave surface (1.4.1)

The placed microwave accepts native and custom items on its solid top through R placement and normal Q drops. Pick up or move the microwave to release resting items into native gravity/flight; they are not carried or attached to it. The optional boolean `"surface": true` catalog field enables this behavior, defaults off, and applies to the microwave, washer, piano and picnic table. Laptop and trash can remain ordinary decorations, including when their lids are closed. Rebuild after catalog edits.

The component-gated target extension retains native support geometry, clearance, self/compound exclusions, obstruction and overlap checks. It changes no layers, tags, collision shapes or Mirror NetworkBehaviours. Native drops keep their existing physics/settlement. A server observer finds resting items over the finite top and uses native detach flight when support moves; stationary items receive no repeated pose/body writes.

In game, test both a native Mug and each custom prop on the microwave: R/place/cancel repeatedly, tap/charge Q onto the top, wait for settlement, save/reload, then pick up and R-move the microwave. Check stable rest without sinking/jitter and natural falls onto the floor. Repeat near the edge, with blocked placement and during a floating-origin shift. Held, stowed, flying and preview microwaves must not become targets. Offline checks do not certify Unity physics or live network timing; vanilla stand-ins retain their native appearance/collision geometry.

## 玩家说明：笔记本与脚踩垃圾桶（1.4.0）

单机主持世界后按 **B** 打开手账，在装饰分类中选择“笔记本电脑”或“脚踩式小垃圾桶”。可照常拾取、按 **R** 放置、丢下或蓄力抛出。重量分别为 **1.5 kg** 和 **1.2 kg**，两者都是普通装饰品，不是容器。

把物品放在世界中，准星对准它，按屏幕“打开 / 关闭”提示显示的**原生次要交互键**即可平滑开合；原有主要交互仍用于拾取。键位跟随游戏的交互绑定与手柄提示，本模组没有新增开合快捷键。笔记本开到 110°，垃圾桶开到 80°。微波炉的门仍为静态装饰。

开合仅限本地主持的单人会话：有其他连接、作为客机或非本地主持时会自动关闭并禁用开合。拾取和进入 R 放置立即关闭；开合状态不存档，每次加载或生成都从关闭状态开始。碰撞体始终使用关闭外形，因此打开的盖子没有额外物理碰撞。

## Data-driven openable parts

An optional catalog field enables a local decorative hinge: `"openable": {"part":"Lid","axis":"x","openAngle":-110,"seconds":0.35}`. Axes `x`, `y`, `z` and signed angles are supported (for example a washer door on `y` at `120`). Optional `openLabel` / `closeLabel` override the default native translation keys with per-item literal prompts. The model must be exported closed with a unique named part and correctly positioned hinge; all material primitives of that part share one pivot. The GLB reader retains the converted node frame alongside baked geometry; the prefab builder unbakes only moving geometry into that frame, leaving root colliders and placement inputs closed. Animation uses smoothstep easing with exact endpoints and supports reversal during motion.

Local decompilation of the supplied `Managed/Assembly-CSharp.dll` confirmed `InteractableHinge` uses `InteractionStateConfig.WithBasicInteraction`, and `InteractionManager` dispatches native primary/secondary actions with input gates and hover/obstruction filtering. The component-gated patch adds a conditional secondary action to the existing HeldItem idle configuration, preserving native pickup. Native UI supplies open/close prompts (configured Chinese labels for washer/piano) and binding glyphs. Startup and hinge diagnostics record the chosen approach; no fallback key, new NetworkBehaviour, open-state save blob or openable network messages are used. The existing catalog network compatibility mechanism remains in place.

## Windows installation

1. Install BepInEx 5 x64 in the game folder (beside the executable), then launch once.
2. Extract **CloudCabin-1.5.8.zip into the game folder**. Mod managers should deploy the archive's `BepInEx` folder to the game root.
3. Confirm this layout:

```text
<Game folder>/BepInEx/plugins/CloudCabin/
    CloudCabin.dll
    cabin_cup.glb
    microwave.glb
    xmastree.glb
    laptop.glb
    trashcan.glb
    lamp.glb
    xmas_tree.glb
    gift_box.glb
    washer.glb
    piano.glb
    items.json
    manifest.json
    README.md
    RELEASE_1.5.8.md
```

Do not install game assemblies or replace BepInEx's Harmony libraries. Follow the upgrade steps above to remove the previous installation before launching.

Open a single-player world and press **B** to open the decorative item spawn menu. Select a polaroid with the mouse or arrow keys, then press **Enter**, click the **Enter** key cap, or double-click the card. **Tab / Shift+Tab** cycles the categories; more than two rows scroll to keep the selected item visible, and the mouse wheel scrolls one row. It spawns in front of the camera using the same placement/network path as before. **Esc**, the **Esc** key cap or B closes the menu. All entries from the embedded `items.json` appear automatically after rebuilding; there is no separate menu list to maintain. Version 1.3.0 uses the travel journal uGUI overlay with a 0.70 s left-hinged fake notebook flip, a 0.18 s close fade, procedural dotted paper/kraft/washi/ring textures and animated selection. It creates no extra HDRP camera or EventSystem. OS serif/handwriting/UI fallback fonts are logged, including SimSun / KaiTi / Microsoft YaHei / Segoe Print on Windows; no font files ship. Scaling matches height at 1920×1080, switches to four columns on narrow screens and clamps scaling for 14px minimum key text. The menu shows the cursor and suspends gameplay look/movement/actions using the native owner-scoped input gate. Closing restores the prior cursor state and releases its input gate after the closing key/click is released. Focus loss, plugin disable and leaving the host world also release it.

Configure `SpawnMenu.ToggleKey` in `BepInEx/config/com.momo_zf.cloudcabin.cfg` (default **B**). Existing unmodified Insert bindings migrate to B and are saved on startup; other custom keys are preserved. The old `Debug.SpawnKey`, `Debug.SpawnItem` and `Debug.InteractionRaycastKey` entries remain unused. At startup the plugin retries Rewired readiness/map loading up to ten times, then dumps every loaded keyboard binding (including disabled maps and the system player) with player, category, layout, action, key and modifiers. A warning identifies any toggle-key collision, including potential gameplay conflicts; check its category and rebind if needed. Each toggle press logs one Info outcome: opened, closed, or ignored with the blocking reason (no local player, no camera, gate held, GameplayInputGate suspended, game menu open).

Click the teal **云上小屋 / Cloud Cabin** stamp in the spawn menu while looking at an item to log the local interaction ray hits, layers, routing, cache membership and native filtered hover/input state. There is no separate diagnostic hotkey. Native hover reports input as suspended while the menu is open; the diagnostic cast still uses the native camera/reach/mask/trigger policy. Every custom item spawn logs each collider’s hierarchy path, type, layer name/index, enabled/trigger flags and native cache membership after `Awake`. Expect `cache=True` and a resolved item name.

Version 1.2.3 also logs the loaded **native mug reference**, before cloning or geometry replacement: root pivot relative to aggregate renderer and physical collider bounds, each renderer’s root-local bounds, every collider’s type and shape dimensions (box center/size, sphere center/radius, capsule center/radius/height/direction, mesh center/size), child transform/scale and layers, plus rigidbody mass, linear/angular drag (Unity 6 damping), interpolation and other physics settings. Values use metres and five decimal places; the root pivot is `(0,0,0)`. Geometry is calculated from local shapes so inactive prefab world bounds do not produce misleading zeros. Aggregate physical collider bounds exclude triggers/disabled shapes, whose raw shape dimensions are still logged individually. In 1.3.3 a missing Mug reference stops initialization with an explicit diagnostic. Cup GUID/address/Mirror identity are unchanged.

Item masses are 0.35 kg (cup), 12 kg (microwave), and 3 kg (tree). All other physics settings come from the native Mug placement reference.

Version 1.3.3 adds per-item `donor` selection: the cup uses `"mug"` and keeps native fill/drink and its liquid meter; microwave and tree use `"plain"`, cloning the neutral WoodenHand decoration (exact base HeldItem). Plain items have no liquid container, pour/drink action or litres icon. Donor candidates log their complete component lists and rejection reasons; the selected donor logs why it was chosen, its unchanged Mirror layout, and the final liquid-component count (`0` for plain items). Native Mug remains the required placement/configuration/collision-layer/rigidbody reference for every item; there is no fallback to a container donor for plain items. Initialization stops with a diagnostic if the required safe donor/reference is unavailable. The 1.3.2 Q behaviour and repeated-R repair remain shared by both donors.

The native save GUIDs, Addressables names and Mirror asset IDs are unchanged. Previously saved microwave/tree instances load through the same GUID into the new plain prefab. Native restore looks up only the current contributors, so old Mug liquid-state blobs are ignored while placement and instance identity still restore. Protocol 10504 and the catalog/layout fingerprint keep older modded peers on compatible native stand-ins.

Version 1.3.2 fixes Q drop/throw freezing in mid-air. Native HeldItem code owns launch gravity, dynamic state, velocities and eventual settlement. Only R entry clears old downward motion; its preview/release pose repair preserves the existing native 1 mm surface clearance. The flight safety net acts only on the local dynamic simulator, after more than 25 cm penetration below a verified finite surface that was below the item. It lifts the item and removes inward velocity without freezing it. Every custom launch logs one `Drop/throw` Info line with actual/native velocities; the first native Mug launch logs the same comparison.

In game, tap and charge Q on all three items and a native Mug: compare the launch lines (`kin=False gravity=True` and matching velocities), confirm each falls and lands, and confirm no `Drop safety recovery` line on normal falls. Repeat R/place/cancel for 20 sessions per item, then Q after R; verify the surface height remains stable. Also check a deliberately tunnelled item returns above the original surface while remaining dynamic, plus shelf edges and moving vehicle surfaces.

Version 1.2.2 fixes the donor filter that excluded the native Mug subclass, prefers a complete native mug clone for the cup, and copies mug placement/physics settings for all three items when available. Surface support includes transformed collider and visible bounds, including scaled primitive fallbacks. R/placement entry and release log target position/rotation, hit surface, bounds/support height, masks and rigidbody state, with another sample after a physics step. The historical fallback is replaced in 1.3.3 by the required native Mug reference. The in-game landing/vehicle checks below remain required.

Version 1.2.1 fixes pickup for all three items and primitive fallbacks: baked colliders live on the HeldItem root so the native detector can resolve them and native layer changes apply to them.

The cup uses the game's pickup, carry, placement, throwing, hotbar, floating-origin and save systems. It is registered as a small Kitchen/Comfort item. Native appearance contracts schedule occasional cups (a rate interval of 6–12 POIs, subject to suitable room/surface and native limits); compatible generic/kitchen archetypes can also select it. Authored legacy kitchen lists retain the cup’s normalized 3% selection chance; the microwave gets 1.8%. Eligible Furniture lists get a 1.2% tree chance. Native entries retain their relative weights. Existing generated/saved loot is not retroactively replaced.

Nomad Spawner versions that read the native loot registry should list **Cloud Cabin Cup**, **Microwave** and **Christmas Tree** automatically; no dependency or separate Spawner patch is required. Search for it in the menu after entering a world. That mod is not included here and its actual menu integration requires an in-game test.

## Model and materials

All thirteen GLBs are loaded directly from beside the DLL; **no AssetBundle or FBX is used**. A small dependency-free GLB 2.0 reader handles the JSON/BIN chunks, float positions/normals, optional UVs, unsigned indices, multiple primitives/materials, scene node TRS/matrices, and nested transforms. It reflects X, transforms normals correctly, and fixes winding. Sparse/compressed/skinned/animated meshes and required extensions are intentionally unsupported.

The shipped cup model is 10.5 cm tall with its pivot at the bottom. `Glass` and `PawPink` render; the `PawPink` mesh uses the pink and darker `PawBean` materials. `Collider` produces a **convex MeshCollider with no renderer**, using its 24 triangles. No texture images are loaded by the GLB reader.

The game uses **HDRP**. Materials clone loaded in-game glass/window/bottle or ordinary opaque materials and change base color only, preserving their existing shader, keywords, blend/depth state and render queue. Glass receives the GLB's light-blue color with alpha **0.25**; paw materials are opaque. The loader prefers native materials with an untextured base map. Other native material properties/maps remain inherited. If no suitable glass material is loaded, model creation falls back to a pink cylinder; it never constructs an HDRP transparent shader variant from scratch.

If the GLB is missing, malformed, or unsupported, the cup still uses a pink cylinder and a box collider. Restart after replacing the file. Keep the bundled model for the expected collider dimensions and footprint.

The microwave is approximately **45 × 34 × 26 cm** (width × depth × height), with `Door` retained as separate static geometry; it has no opening interaction. The tree’s supplied source README specifies **91.4 cm including its star**, with foliage around 86.5 cm. This differs from the brief’s nominal 86 cm. All models keep their authored metre coordinates with root scale `(1,1,1)`; nothing is resized. Microwave and tree footprints are derived from baked model bounds; the cup retains its released footprint. The tree uses floor/ground loot surfaces, while the cup and microwave use shelf/counter/table surfaces.

`Lights` preserves its warm emissive factor `[1, .55, .15]` and strength `4`. It clones a loaded native opaque emissive material, retaining its shader variant and setting the HDR emission color; inherited emission textures/intensity multipliers are neutralized. No new scene lights are created. If a suitable native material is unavailable, model construction uses the primitive fallback and logs the reason. Version 1.2.4 loads the supplied transparent 256×256 PNG icons with UnityEngine.ImageConversion.LoadImage for inventory/hotbar sprites and spawn-menu thumbnails. Missing, unconfigured or invalid PNGs log a warning and use the existing procedural icon (paw for the cup, rasterized GLB triangles for other items). Sprites and textures are shared with the menu and released during plugin cleanup.

## Adding decorative items

Add one row to `items.json` with `id`, `displayName`, `glb`, and exactly one `category` (`Furniture`, `Kitchen`, `Decor`, or `Outdoor`). All four appear in 全部. Add a positive `lootWeight`, the `donor` (`mug` for liquid cups, `plain` by default), and `mass` in kilograms (0.5 kg for the Mug reference). Optional fields are `icon`, `menuName` (defaults to `displayName`), and `lootCategory` (a native `LootCategory` enum name that overrides the random loot pool). The default native loot pool is Kitchen for Kitchen and Furniture for the other catalog categories. Rebuild and ship the GLB beside the DLL and the PNG at its configured relative path. Use GLB-verified Unity XYZ metre bounds for optional offline generator `footprint` metadata. Runtime footprints derive from the GLB. The JSON is embedded at build time, and the packaged copy is a reference. Icons, registry entries, contracts, persistence, addressable locations, size/footprint and donor selection are generated for each row. The packaging script discovers model filenames from this table.

Item IDs are permanent save keys. Keep released item IDs, Addressables addresses and Mirror asset IDs when changing display names.

## Save compatibility

Saves store a permanent Addressables item GUID and unique instance GUIDs through the native save system. Keep this plugin installed when loading cup saves. **Back up saves before removing it**: loading and re-saving without its Addressables provider may discard cup records. Live plugin unloading is unsupported.

## In-game verification checklist

Verify journal fonts, 1080p/1440p/narrow layouts, flip/close timing (including rapid B/Esc), tab counts, arrow wrapping, mouse hover/click/double-click, empty categories and scrolling. Check selection ring/tape movement under rapid presses, and mass values in prefab diagnostics. These checks still require a Windows game run; this workspace only provides managed assemblies.

- Launch and inspect `BepInEx/LogOutput.log` for each item’s `ready` message, selected stand-in and material clone names. There should be no DI, unknown asset ID, shader or deserialization errors.
- Check startup Rewired binding logs and any toggle-key conflict warnings. In single-player, the menu lists Cloud Cabin Cup, Microwave and Christmas Tree by name. Select each, confirm once by click and once by Enter, and check exactly one selected item spawns per confirmation. The title screen must not open/spawn. Rebind `SpawnMenu.ToggleKey`, restart and repeat. F8 should retain native bug-report behavior and F9 should not spawn or run mod diagnostics.
- While the menu is open, move the mouse and press movement, interaction, hotbar, placement and driving controls: gameplay must remain blocked and the cursor visible. Close by Esc, its key cap and B; check the original cursor lock/visibility and prior on-foot/held/vehicle input mode return after releasing the closing key/click. Esc must not also open pause. Repeat focus loss, leaving the world, plugin disable and attempts while native chat/console/pause is open; other gate owners must stay suspended.
- Look at a cup, open the menu and click the teal postmark to log the interaction raycast; check ray hits, layers and routing (native hover is blocked while the menu is open). Inspect `Placement native mug` logs for renderer/collider root bounds and pivot offsets, every shape dimension in metres, layers, mass, drag/damping and interpolation. A missing required Mug or WoodenHand must stop initialization with the candidate rejection reasons.
- Check cup model size, bottom pivot, pink inner paw/pads, light-blue transparent glass and absence of a rendered collider. Test daylight, darkness, glass overlap and views from inside/behind the glass.
- Pick up/carry, drop, rotate/place on shelves and vehicle surfaces, throw, and stow/retrieve from hotbar. Confirm the paw icon and reasonable hand pose. Move/drive across a floating-origin shift.
- Check a new and previously saved microwave/tree: no litres icon, pour or drink action while hovering, equipped or in hotbar. Fill/drink the cup and confirm its meter still works. Inspect `donorSetting=plain, liquidComponents=0` for both decorations. Save/reload a 1.3.2 world containing them and confirm count, instance GUID, hotbar slot and vehicle placement persist.
- Save with one cup placed on the vehicle and another in hotbar; reload. Check item count, position, parent placement and hotbar slot. Repeat after returning to the menu and hosting again.
- With Loot.RandomSpawn=false, visit newly generated POIs to confirm custom items do not enter world loot. Only opt-in true enables the historical loot tests. Test Nomad Spawner's native-registry item list and preview/spawn path.
- Repeat pickup, hotbar, placement, vehicle save/reload, default-off/opt-in loot for **each item**. Select each entry in the spawn menu and check its own name/icon. Add a valid extra catalog row/model in a test build and verify its display name and spawn selection appear without menu code edits. Confirm the microwave Door stays static and the tree lights retain warm emission in darkness.
- Rename each GLB in turn, restart and confirm the primitive fallback still interacts and persists.

Open risks are native donor availability, loaded glass material availability/inherited properties, HDRP transparency sorting/stripped variants, native loot frequency, and runtime save/placement behavior. These are not proven by compilation or parser tests.

## 1.5.0 preset van / 车辆预设（单人预览）

导出框架识别 Rv-C、RV-1986、RV-SchoolBus。本版内置预设可试用车型为校车与复古 RV；Rv-C 仍须绑定真实 GUID。Rv-Hippie、Motorcycle-01 暂不支持。
必须是本地单人主机，远程玩家连接后立即拒绝/中止。坐在车内或站在车上时优先选择当前车，
否则选择 15 米内最近的支持车型。导出和应用时请停车，关闭背包/菜单与导演模式。

- `Preset.DevExport=false`：开发录制开关；设为 true 后按 **Ctrl+Shift+E** 导出。
- `Preset.ExportKey=Ctrl+Shift+E`、`Preset.ApplyKey=Ctrl+Shift+P`：组合键，支持左右 Ctrl/Shift；
  配置格式为 `Ctrl+Shift+字母`，不允许 B、Insert 或功能键，两个组合键不可相同。
- `Preset.ExportName=`：留空使用 `<车型>-<UTC yyyyMMdd-HHmmss>`；可改为仅含英文字母、数字、下划线、短横线的名字。
  已存在的文件夹不会覆盖。
- `Preset.ActivePreset=`：留空选择车型名、非全零 prefab GUID 相同且 createdUtc 最新的预设；否则填写预设文件夹名。
- `Preset.IfNotEmpty=Refuse`：车内已有任何原生放置物品时拒绝。Append/Stash 仅预留枚举，当前一律拒绝。

录制：在支持的车上摆好原版或目录物品、完成车身/车门等涂装，开启 DevExport，按导出组合键。
居中大字中文提示会显示八秒，详细跳过原因写入 BepInEx 日志。放置在原生吸附平面上的多层物品会按父子关系记录；
车辆模块/车门/发动机等已安装部件、手持/收纳/飞行/摆放预览中的物品不会作为摆件导出。
涂装只记录相对出生状态发生变化的纹理；颜色 0 与遮罩 3 成对记录，污渍/锈/抛光/金属 1/2/4/5 改变时也记录。

自定义预设导出到 `BepInEx/config/CloudCabin/presets/<name>/`，内置预设随插件放在 `BepInEx/plugins/CloudCabin/presets/`。同名时优先读取配置目录。插件也能读取仍在旧插件目录中的预设数据。
新导出写入 `formatVersion: 2`，读取兼容 1 和 2。包括插件版本、UTC 时间、车型 GUID/名字、物品标识、
父容器/部件、平面 id、局部姿态与顺序、表面 id、纹理类型和实际 PNG 尺寸。
分享时复制整个文件夹；不包含安装部件或物品内容/液体/开关状态。

每件物品恰好使用一个非 null 标识（其余字段可省略或为 null）：

- `prefabGuid`：32 位十六进制 Addressables GUID，原导出文件继续可读。
- `prefabAddress`：原版 Addressables 地址或 prefab 名称，例如 `"Beer"`；长度 1–128，
  只允许 ASCII 字母、数字、空格和 `- _ . ( )`，不允许路径分隔符、控制符或分号。
- `catalogId`：本插件 `items.json` 的永久 id，例如 `"lamp"`，运行时映射为本插件 GUID。

导出器始终使用 `prefabGuid`；运行时注册表能唯一反查地址时，另写只供阅读的 `prefabAddressHint`。
提示字段不参与查找，也不算第二个标识，因此不要把它改名为 `prefabAddress` 后保留 GUID。
旧版 v1 导出器曾在 GUID 旁附带 `catalogId` 元数据；读取时保留 GUID 并丢弃该旧提示。
新 v2 文件混用两个或更多标识会被拒绝。离线生成器使用原版 `prefabAddress` 或本插件 `catalogId`。

仓库提供 [tools/preset_gen](../tools/preset_gen/README.md)（Python 3、Pillow、numpy），从仓库根目录运行：

```sh
timeout 300 python3 tools/preset_gen/preset_gen.py --layout /workspace/van_layouts/c_class_rv/layout.json --van-data /workspace/van_data --out /workspace/van_layouts/c_class_rv --vehicle Rv-C --name christmas-cabin-preview --preset-file generated_preset.json --side
timeout 300 python3 -m unittest discover -s tools/preset_gen/tests -v
```

生成中文 `check_report.md`、按米制重绘的 `placement_top.png` 和预设 JSON；layout v2 另生成侧视图，默认名为
`generated_preset.json`，正式打包为 `preset.json`；旧格式默认 `preset.json`。不复制 van_data 或模型到仓库。
保留设计尺寸，不自动缩放/吸附；有错误的物品及失效支撑链不会导出。报告逐件列出过滤、旋转包围盒、净高和堆叠问题。
车型 GUID 缺失时使用明确的全零未绑定占位，JSON 可解析但不能应用到真实车；从游戏导出取得 GUID 后加
`--vehicle-guid <32位GUID>` 重跑。未知物品平面的预览堆叠使用 `planeId=0` 并警告需要游戏捕获，
不能当成已验证平面。`ItemSurface` 不等于 SnappingPlane。不带 `--graffiti` 时仅报告 decal 候选；带该参数时由
[graffiti_bake](../tools/graffiti_bake/README.md) 生成原生颜色/遮罩与五视图，内置三份预设已使用该流程。
C# 回归会用生产 `PresetJson.Parse` 解析已提交的合成生成样例；设 `PRESET_GENERATOR_OUTPUT` 为外部生成的 JSON 路径，
即可在上面的十 GLB C# 测试命令中额外解析实际输出。

地址解析顺序：当前世界 `LootRegistry.GetByAddress` 精确匹配 → 不区分大小写的地址 →
prefab 名称/地址末段或 displayName。每层仅接受唯一 GUID，歧义或缺失则跳过，不猜测。
按每次应用缓存结果；载入与原生保存都使用解析出的 GUID。
注册表不可用时会在日志提示并尝试直接按地址加载，再从实时 Addressables catalog 反查唯一保存 GUID；
反查不到或存在歧义时也跳过，避免产生无法重载的物品。
请勿将预设理解为整车存档：它只重建 loose placed items 与改变过的表面纹理。

应用：准备同类型空车，按 **Ctrl+Shift+P**。每帧最多生成一件物品，父物品先生成；失败物品销毁，其子树跳过，
其余物品继续。缺少/重复匹配的车门部件或表面会记录并跳过，结束显示物品和表面成功/跳过数。
预设不是事务：中断或部分失败会留下已经成功的物品和涂装，清空车辆后才可重试。
完成后使用游戏的正常保存；原生 placement/restoration contributors 负责持久化，无新增存档格式。
已安装模块必须事先匹配；本功能不生成车门、发动机或附加模块。

Native protocol/catalog code is **10501** in 1.5.1 because washer/piano extend the catalog. Existing identities,
Mirror component layouts and wire payloads remain stable in 1.5.2. Decal projection is offline; no new NetworkBehaviour, messages, layers or save contributors.
Native director mode consumes P and free-camera E; preset shortcuts are blocked while director mode, game menus
or the native gameplay input gate are active. User-rebound Rewired combinations still need an in-game collision check.

In-game verification required: vanilla address (Beer), case variants, prefab/display names, ambiguous/missing entries,
registry-unavailable fallback and GUID save/reload; all three vehicle types; native/custom three-deep stacks; installed inactive module
planes; matching/missing/ambiguous doors; nonempty refusal; wrong vehicle; remote join during async load;
world exit during export/apply; all six paint channels and actual texture resolutions; save/reload; Chinese toast glyphs.
Offline tests check JSON/ordering/policy and compiled/native API contracts, not Unity physics, GPU readback or live transport.
