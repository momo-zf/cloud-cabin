# 1.5.3 测试版车辆预设

在空车内/车上按 **Ctrl+Shift+P** 应用。仅支持本地单人主机；停车、关闭菜单/导演模式。车内已有放置物品会拒绝。`Preset.ActivePreset` 留空时按车型名＋非全零 GUID 选择最新预设，也可指定文件夹。

| 文件夹 | 车型 | 内容与状态 |
|---|---|---|
| `school_bus` | RV-SchoolBus | 音乐客厅＋洗衣角，33 件清单物品、4 张原生喷漆 PNG；真实身份已绑定 |
| `retro_rv` | RV-1986 | 复古创作者书房，32 件、6 张 PNG；尾条纹已收在尾灯之间，右条纹避让门洞；真实身份已绑定 |
| `c_class_rv` | Rv-C | 圣诞小木屋，23 件、26 张 PNG；**UNBOUND，车型 GUID 仍是全零占位，禁止应用** |

校车 GUID：`df321578632574b4a9d3394dbb489933`；复古 RV GUID：`d699ecbfb8a228245ab2a9867bc962e5`。C 型车的车型和未绑定喷漆零件都须捕获真实 GUID 后重新生成，不能只改车型名字。

三车离线布局检查均为 0 errors。校车 16、复古 RV 17、C 型车 9 个叠放条目尚用 `planeId=0` / 假设父平面帧：没有真实平面时会跳过它们及其子链。NEW_ITEM 不在清单中。复古 RV 门侧证据冲突、UV 重叠、Unity 色彩/遮罩上传与存档仍待游戏验证；这些是预览限制，不能将 0 errors 当成全部条目已可实机恢复。

每份目录只有 **preset.json + paint/*.png**；复制整个目录分享，保持 PNG 相对路径。插件写入 formatVersion 2，读取兼容 1/2。生成的摆件与涂装用游戏正常存档保存，不包含已安装模块、容器内容/液体/开关状态。应用允许部分成功；查看屏幕中央 8 秒提示和日志中的成功/跳过数，清空车内后才能重试。

设 `Preset.DevExport=true` 后按 **Ctrl+Shift+E** 开发录制，文件保存到 `BepInEx/config/CloudCabin/presets/`。同名预设优先使用配置目录中的版本。旧预设文件可直接读取，杯子的旧标识会解析为 `cloudcabin_cup` 对应的物品。

每个物品恰好使用一个 selector：`prefabGuid`（32 位十六进制）、`prefabAddress`（原版地址，例如 Beer），或 `catalogId`（本插件永久 id）；其余省略/null。`prefabAddressHint` 仅供阅读。旧 v1 GUID 旁的 catalogId 元数据仍兼容；不要在 v2 混用 selector。

运行时从原生注册表依次按精确地址、不区分大小写地址、prefab 名/显示名查找唯一 GUID；歧义/缺失则跳过。只有注册表不可用时才尝试直接 Addressables 地址回退，仍必须取得真实保存 GUID。不要混用车型或零件 GUID。
