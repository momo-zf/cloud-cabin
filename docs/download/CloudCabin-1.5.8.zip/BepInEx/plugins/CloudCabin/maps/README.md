# 设计地图 / Designer maps

每张地图放在 `maps/<id>/map.json`；模型为 `export/visual/*.glb` 与 `export/collider/*.glb`，预览为本目录 PNG。只接受自包含 GLB 2.0、米制、顶点色（不使用外部纹理）。

```json
{"id":"home","displayName":"小家","description":"设计的小家","order":0,
 "visualDir":"export/visual","colliderDir":"export/collider","colliderMode":"boxes",
 "designerOffset":[0,0,0],"designerYaw":0,
 "playerSpawn":[0,0.05,0],"playerYaw":0,"vehicleSpawn":[5,0.05,-5],"vehicleYaw":0,
 "killY":-20,"halfExtent":30,"persistent":true,"clearItemsOnReturn":false,
 "defaultItems":[],"previewImage":"preview.png"}
```

`id` 为小写字母/数字/下划线。必须提供 id、displayName、description、playerSpawn、vehicleSpawn、killY、halfExtent。路径必须相对，不含 `..`。所有数值必须有限。`order` 小者在前。`clearItemsOnReturn` 默认等于 `!persistent`。同 id 文件夹地图替换内置地图（例如 home 替换灰盒）；多个文件夹同 id 时按文件夹名排序，第一个有效者保留。无效定义会记录原因并跳过。

设计坐标 Blender X=东、Y=北、Z=上，单位米；GLB 标准 glTF 轴由导出器处理。加载器使用现有 X 镜像 + MapRoot Y180，再施加 designerYaw / designerOffset。出生点/defaultItems 坐标已经是转换后的地图本地 Unity X=东、Y=上、Z=北；yaw 0 朝北，90 朝东。colliderMode auto 对名字含 box 的节点使用 bounds BoxCollider，否则静态非凸 MeshCollider；boxes 对所有碰撞节点在其原始节点坐标系中使用定向盒子，最小厚度 0.05m；可通过 `"meshColliders": [...]` 指定保持为静态非凸 MeshCollider 的节点（如悬空岛的 `Collider_Ground` 与 `Collider_Island_Under_1..5`）。

Each map is a folder with the JSON above, self-contained metre-scale GLB 2.0 visual/collider exports and optional PNG. Vertex colours only. Required fields and safe relative paths are strictly validated. Spawn/item coordinates are **map-local Unity coordinates after designer conversion**. Folder maps can override built-ins; duplicate folder IDs keep the first valid folder in lexical order. Smaller order sorts first. Persistent maps keep contents per save; non-persistent maps clear new items on return.

## 门窗、摆放与出生点（1.5.7） / Moving leaves and placement

发行包的 `maps/home` 替换内置灰盒：41.881×41.160米悬空岛（深 13.2 米、41 根垂根、开放岛沿无空气墙、院门外碎石场地 `Gravel_Apron`、`halfExtent=30`、`killY=-20`）、25米院子、批准的木屋框架、室内空置、空菜畦（`Yard_VegetableBed` 仅木框与土）与约 20% 庭院草花。五件庭院默认物品仅首次每存档生成，之后按普通可移动物品保存；已有 defaultsSpawned=true 的存档不补发。模型使用 Y180 根变换，defaultItems 使用设计布局 unity_position/unity_yaw_deg，不使用 direct 字段。步行 (-4.4,0,-2.6)/22.8°；车 (4.95,0.02,4.8)/180°；玩家驾驶侧 (6.75,0.02,4.8)/270°。

JSON 可加 `"carPlayerSpawn":[4.2,0.05,-7], "carPlayerYaw":90`。省略时：vehicleSpawn 的左侧 1.8米，随 vehicleYaw 旋转；carPlayerYaw 默认 vehicleYaw。坐标需留出真实车辆尺寸与玩家胶囊净空，运行时仍检查落点净空。

视觉节点以 `Door_` 或 `Window_` 开头（区分大小写），例如 `Door_Main` / `Window_East`。**节点原点就是铰链轴心，关闭姿态导出；应用 scale，避免负缩放/剪切。** 同一节点所有材质 primitive 共用一个轴心；节点名跨文件唯一。子节点（例如窗玻璃）随最近的叶片祖先一起运动，不单独交互。碰撞单独导出，叶片碰撞节点与视觉同名或追加 `_Collider`，加载器按闭合叶片局部 bounds 建盒；缺失时用视觉 bounds 建盒。不要把活动叶片焊进静态墙碰撞：墙体必须真的挖门/窗洞。静态几何使用 Ground；活动叶片碰撞与 MapOpenable 在同一 Interactable GameObject，子视觉保留 Default 供原生描边。

```json
"openables":[
  {"node":"Door_Main","axis":"y","openAngle":95,"seconds":0.6,"label":"门"},
  {"node":"Window_East","axis":"y","openAngle":80,"seconds":0.6,"label":"窗"},
  {"node":"Window_West","axis":"y","openAngle":-80,"seconds":0.6,"label":"窗"}
]
```

前缀节点自动作为活动叶片；未配置条目时 door 默认 Y/95°/0.6秒/门，window 默认 Y/80°/0.6秒/窗。axis 支持 x/y/z，角度可正负但绝对值≤180且非零，seconds>0且≤60。原生 look+主交互键显示开门/关门/开窗/关窗，不新增F快捷键。动画全程检查玩家，受阻停止；状态按稳定节点名保存。灰盒固定ID为 door_main/window_east/window_west；文件夹地图将节点名转小写作为稳定ID，因此 Door_Main / Window_East / Window_West 可沿用灰盒的状态；改变节点名视为新门窗。

摆放面规则：地板、门廊、墙应提供非trigger静态 Ground 碰撞，不只导出视觉。不要把整个小屋做成一个实心碰撞盒。使用原生 R 自由摆放；不添加伪 SnappingPlane。门窗叶片用于交互/挡人，活动面不承诺承载摆放物。

Optional carPlayerSpawn/carPlayerYaw control driver-side arrival; default is 1.8m left of the vehicle in its yaw frame. Door_/Window_ nodes retain their closed hinge frame and animate locally using the native interaction key/prompt, without new network identities. Apply scale and avoid shear/negative scale. Match separate leaf collider node names, or visual bounds supply a box. Export real wall apertures and Ground support colliders for floors, porch and walls. No artificial snapping planes are added. Openable entries override the defaults above; axis/angle/duration are validated. Folder leaf state IDs are node names converted to lowercase (Door_Main shares gray-box door_main).

## 保存 / Persistence

`persistent:true` 地图按游戏存档槽与地图id各自保存物品、默认物品生成标记与门窗状态。`clearItemsOnReturn` 默认 `!persistent`；持久化地图离开前先快照，再移除现场物品，随身/车上物品不清理。默认物品可用 itemId（模组目录）或32位 addressable guid（两者选一），position/yaw是地图本地坐标；内置小家 defaultItems 为空，不生成默认物品。map.json不包含玩家物品保存文件，发行包不得带 mapsaves。

State files live under BepInEx config, independently of designer exports. A persistent map snapshots its disposable scene before return; player inventory and vehicle-owned items remain with the game. Configured defaults spawn once per slot/map; the built-in home has none and starts with an empty cabin. Only item records are restored, never vehicles. `openables.axis` refers to the retained node's local Unity axes after GLB conversion.
